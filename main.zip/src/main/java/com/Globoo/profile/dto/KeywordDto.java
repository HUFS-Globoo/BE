package com.Globoo.profile.dto;

public record KeywordDto(Long id, String name) {}
