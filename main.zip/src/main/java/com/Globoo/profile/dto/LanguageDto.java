// LanguageDto.java
package com.Globoo.profile.dto;

public record LanguageDto(String code, String name) { }
