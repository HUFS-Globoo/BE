package com.Globoo.auth.dto;

public record OkRes(boolean ok) {}
