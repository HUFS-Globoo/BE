package com.Globoo.chat.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ChatRoomCreateResDto {
    private Long roomId; // 생성된 채팅방 ID
}
//pr 차이