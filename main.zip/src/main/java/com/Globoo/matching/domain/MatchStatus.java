package com.Globoo.matching.domain;

public enum MatchStatus {
    WAITING,
    FOUND,
    SKIPPED,
    ACCEPTED_ONE,
    ACCEPTED_BOTH
}
