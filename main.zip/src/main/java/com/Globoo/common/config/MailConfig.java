package com.Globoo.common.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class MailConfig { }
