package com.Globoo.message.repository;


import com.Globoo.message.domain.DmThreadParticipant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DmThreadParticipantRepository extends JpaRepository<DmThreadParticipant, Long> { }
