// src/main/java/com/Globoo/user/dto/LanguageRes.java
package com.Globoo.user.dto;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LanguageRes {
    private String code;
    private String name;
}
