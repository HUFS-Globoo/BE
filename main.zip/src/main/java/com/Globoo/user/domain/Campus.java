// src/main/java/com/Globoo/user/domain/Campus.java
package com.Globoo.user.domain;

public enum Campus {
    SEOUL, GLOBAL
}
