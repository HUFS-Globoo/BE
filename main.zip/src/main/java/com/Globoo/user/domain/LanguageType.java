package com.Globoo.user.domain;

public enum LanguageType {
    NATIVE,   // 모국어
    LEARN     // 배우는 언어
}
