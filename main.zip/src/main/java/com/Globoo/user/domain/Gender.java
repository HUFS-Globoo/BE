// src/main/java/com/Globoo/user/domain/Gender.java
package com.Globoo.user.domain;

public enum Gender {
    MALE, FEMALE
}
