// src/main/java/com/Globoo/user/domain/MBTI.java
package com.Globoo.user.domain;

public enum Mbti {
    ISTJ, ISFJ, INFJ, INTJ,
    ISTP, ISFP, INFP, INTP,
    ESTP, ESFP, ENFP, ENTP,
    ESTJ, ESFJ, ENFJ, ENTJ
}
